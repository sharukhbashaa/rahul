import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caseinfo',
  templateUrl: './caseinfo.component.html',
  styleUrls: ['./caseinfo.component.css']
})
export class CaseinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
