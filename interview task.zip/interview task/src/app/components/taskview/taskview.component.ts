import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taskview',
  templateUrl: './taskview.component.html',
  styleUrls: ['./taskview.component.css']
})
export class TaskviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
